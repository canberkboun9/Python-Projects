ReadMe file for Cmpe493 Project4 2021 Fall Bogazici University

Python version = 3.8.12

1.1- Only module, that is, the main.py file.
1.2- User must put the data file into the same directory with main.py
1.3- One can simply run it by writing to the terminal main.py, and it would start running.
1.4- While it runs, it reads the data and performs all the processes.
1.5- Program prints outputs to the console that user may want to read as a report.
