ReadMe file for Cmpe493 Project1 2021 Fall Bogazici University

Python version = 3.8

1.1- First module, that is, indexing part is the main.py file.
1.2- User must put the SGML files into the same directory with the two scripts that are two modules.
1.3- One can simply run it by writing to the terminal main.py, and it would start running.
1.4- While it runs, it reads the data and do the indexing.
1.5- At the end two json files occurs, that is the inverted index file called samples.json, and the vector space file, called vector_space.json.

2.1- Second module, that is, query processing part is the query_processor.py file.
2.2- One can simply run it by writing to the terminal query_processor.py, and it would start running.
2.3- While it runs, it takes input from console from the user, it prints helping texts as guide lines for the user.
2.4- When user enters their query, the program outputs the result to the console.
2.5- Then, it asks user to enter the letter 'Q' if they want to quit. User can enter lowercase or uppercase Q, it doesn't matter.
2.6- By entering another string, user can continue query processing by entering the next query.

It is a user friendly query processor.